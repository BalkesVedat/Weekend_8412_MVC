﻿using Microsoft.AspNetCore.Mvc;

namespace TestUygulamasi.Controllers
{
    public class HesapController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public string MesajVer()
        {
            return "Merhaba";
        }

        private double Topla()
        {
            return 155 + 255;
        }

        private double Topla(double sayi1, double sayi2)
        { 
            return sayi1 + sayi2;
        }

        public IActionResult Sonuc()
        {
            ViewBag.Toplam = Topla(500,750);
            ViewBag.Mesaj = "Vedat Gümüşkuyu";

            ViewData["Tarih"] = DateTime.Now;

            return View("SonucGoster");
        }


    }
}
