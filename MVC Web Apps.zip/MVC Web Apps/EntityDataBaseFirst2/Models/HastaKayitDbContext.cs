﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EntityDataBaseFirst2.Models;

public partial class HastaKayitDbContext : DbContext
{
    public HastaKayitDbContext()
    {
    }

    public HastaKayitDbContext(DbContextOptions<HastaKayitDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Hastalar> Hastalars { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        => optionsBuilder.UseSqlServer("Server=.;Database=HastaKayitDB;User ID=sa;Password=1;Trust Server Certificate=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Hastalar>(entity =>
        {
            entity.HasKey(e => e.HastaId);

            entity.ToTable("Hastalar");

            entity.Property(e => e.HastaId).HasColumnName("HastaID");
            entity.Property(e => e.AdSoyad).HasMaxLength(50);
            entity.Property(e => e.AktifMi).HasDefaultValue(true);
            entity.Property(e => e.BorcTutari)
                .HasDefaultValue(0m)
                .HasColumnType("money");
            entity.Property(e => e.Tarih)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("smalldatetime");
            entity.Property(e => e.Telefon)
                .HasMaxLength(15)
                .IsUnicode(false);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
