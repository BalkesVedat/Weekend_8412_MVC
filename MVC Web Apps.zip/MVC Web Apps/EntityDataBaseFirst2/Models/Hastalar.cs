﻿using System;
using System.Collections.Generic;

namespace EntityDataBaseFirst2.Models;

public partial class Hastalar
{
    public int HastaId { get; set; }

    public string AdSoyad { get; set; } = null!;

    public string? Adres { get; set; }

    public string? Telefon { get; set; }

    public string? Sikayetler { get; set; }

    public DateTime? Tarih { get; set; }

    public bool? AktifMi { get; set; }

    public decimal? BorcTutari { get; set; }
}
