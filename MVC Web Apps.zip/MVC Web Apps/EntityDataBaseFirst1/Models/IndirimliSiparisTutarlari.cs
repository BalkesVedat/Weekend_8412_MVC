﻿using System;
using System.Collections.Generic;

namespace EntityDataBaseFirst1.Models;

public partial class IndirimliSiparisTutarlari
{
    public int OrderId { get; set; }

    public int ProductId { get; set; }

    public decimal UnitPrice { get; set; }

    public short Quantity { get; set; }

    public float Discount { get; set; }

    public decimal? Tutar { get; set; }

    public float? İndirim { get; set; }

    public float? SatışTutarı { get; set; }
}
