﻿using System;
using System.Collections.Generic;

namespace EntityDataBaseFirst1.Models;

public partial class GetCountryList
{
    public string? Country { get; set; }
}
