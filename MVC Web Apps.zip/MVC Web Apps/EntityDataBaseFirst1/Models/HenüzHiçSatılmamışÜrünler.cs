﻿using System;
using System.Collections.Generic;

namespace EntityDataBaseFirst1.Models;

public partial class HenüzHiçSatılmamışÜrünler
{
    public int ProductId { get; set; }

    public string ProductName { get; set; } = null!;
}
