﻿using System;
using System.Collections.Generic;

namespace EntityDataBaseFirst1.Models;

public partial class KategoriyeGöreStokDeğerleri
{
    public int? CategoryId { get; set; }

    public string CategoryName { get; set; } = null!;

    public decimal? StokDeğeri { get; set; }
}
