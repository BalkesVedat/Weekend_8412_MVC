﻿using System;
using System.Collections.Generic;

namespace EntityDataBaseFirst1.Models;

public partial class MüşteriyeGöreSatışToplamları
{
    public string CompanyName { get; set; } = null!;

    public string? Country { get; set; }

    public string? City { get; set; }

    public decimal? ToplamTutar { get; set; }
}
