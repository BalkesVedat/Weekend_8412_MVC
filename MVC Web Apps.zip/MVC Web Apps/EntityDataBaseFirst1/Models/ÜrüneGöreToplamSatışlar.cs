﻿using System;
using System.Collections.Generic;

namespace EntityDataBaseFirst1.Models;

public partial class ÜrüneGöreToplamSatışlar
{
    public int ProductId { get; set; }

    public string ProductName { get; set; } = null!;

    public decimal? OrtalamaBf { get; set; }

    public int? ToplamAdet { get; set; }

    public decimal? ToplamTutar { get; set; }
}
