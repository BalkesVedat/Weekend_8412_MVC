﻿using System;
using System.Collections.Generic;

namespace EntityDataBaseFirst1.Models;

public partial class LogTbl
{
    public int LogId { get; set; }

    public DateTime? LogDate { get; set; }

    public string? LogUser { get; set; }

    public string? LogProcess { get; set; }

    public string? LogDetails { get; set; }
}
