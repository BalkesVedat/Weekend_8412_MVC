﻿using System;
using System.Collections.Generic;

namespace EntityDataBaseFirst1.Models;

public partial class SatışMaliyetKarAnaliziRaporu
{
    public int ProductId { get; set; }

    public string ProductName { get; set; } = null!;

    public decimal? AlışFiyatı { get; set; }

    public decimal SatışFiyatı { get; set; }

    public short Quantity { get; set; }

    public decimal? Maliyet { get; set; }

    public decimal? SatışTutarı { get; set; }

    public decimal? KarZarar { get; set; }
}
