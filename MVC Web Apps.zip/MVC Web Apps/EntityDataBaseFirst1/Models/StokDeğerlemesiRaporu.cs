﻿using System;
using System.Collections.Generic;

namespace EntityDataBaseFirst1.Models;

public partial class StokDeğerlemesiRaporu
{
    public string CategoryName { get; set; } = null!;

    public string? KategoriAçıklaması { get; set; }

    public int? ÜrünAdedi { get; set; }

    public decimal? ToplamStokDeğeri { get; set; }
}
