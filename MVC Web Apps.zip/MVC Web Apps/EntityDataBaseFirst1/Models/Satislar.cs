﻿using System;
using System.Collections.Generic;

namespace EntityDataBaseFirst1.Models;

public partial class Satislar
{
    public int SatisId { get; set; }

    public DateTime? Tarih { get; set; }

    public int? Musteri { get; set; }

    public decimal? Tutar { get; set; }
}
