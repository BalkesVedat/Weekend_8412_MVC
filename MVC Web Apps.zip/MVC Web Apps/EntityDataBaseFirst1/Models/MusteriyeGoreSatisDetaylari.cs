﻿using System;
using System.Collections.Generic;

namespace EntityDataBaseFirst1.Models;

public partial class MusteriyeGoreSatisDetaylari
{
    public long? Sıra { get; set; }

    public string Müşteri { get; set; } = null!;

    public string? Country { get; set; }

    public int OrderId { get; set; }

    public string? SiparişTarihi { get; set; }

    public string? NakliyeTarihi { get; set; }

    public string ProductName { get; set; } = null!;

    public decimal UnitPrice { get; set; }

    public short Quantity { get; set; }

    public string? Tutar { get; set; }
}
