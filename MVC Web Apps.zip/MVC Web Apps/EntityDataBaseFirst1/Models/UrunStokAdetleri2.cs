﻿using System;
using System.Collections.Generic;

namespace EntityDataBaseFirst1.Models;

public partial class UrunStokAdetleri2
{
    public string ProductName { get; set; } = null!;

    public int? ToplamStokAdedi { get; set; }
}
