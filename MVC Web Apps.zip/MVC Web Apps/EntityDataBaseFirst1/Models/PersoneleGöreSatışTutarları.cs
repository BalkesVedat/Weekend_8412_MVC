﻿using System;
using System.Collections.Generic;

namespace EntityDataBaseFirst1.Models;

public partial class PersoneleGöreSatışTutarları
{
    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public string? Title { get; set; }

    public decimal? ToplamTutar { get; set; }

    public int? ToplamAdet { get; set; }
}
