﻿using System;
using System.Collections.Generic;

namespace EntityDataBaseFirst1.Models;

public partial class ProcessLog
{
    public int LogId { get; set; }

    public string? LogText { get; set; }

    public string? UserName { get; set; }

    public DateTime? ProcessDate { get; set; }
}
