﻿using System;
using System.Collections.Generic;

namespace EntityDataBaseFirst1.Models;

public partial class SiparişeGöreSatışTutarlarıRaporu
{
    public int OrderId { get; set; }

    public string? ToplamTutar { get; set; }

    public string? İndirimlerToplamı { get; set; }

    public string? Ciro { get; set; }

    public double? CurCiro { get; set; }
}
