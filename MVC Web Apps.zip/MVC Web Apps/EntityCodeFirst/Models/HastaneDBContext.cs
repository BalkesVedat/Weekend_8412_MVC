﻿using Microsoft.EntityFrameworkCore;

namespace EntityCodeFirst.Models
{
    public class HastaneDBContext : DbContext
    {
        public HastaneDBContext()
        {

        }

        public HastaneDBContext(DbContextOptions<HastaneDBContext> options) : base(options)
        {

        }

        public virtual DbSet<Hasta> Hastalar { get; set; }
        public virtual DbSet<Doktor> Doktorlar { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
       => optionsBuilder.UseSqlServer("Server=.;Database=HastaneDB;User ID=sa;Password=1;Trust Server Certificate=True");


    }
}
