﻿using System;
using System.Collections.Generic;

namespace Eticaret8412Admin.Models;

public partial class Customer
{
    public int CustomerId { get; set; }

    public string? CustomerName { get; set; }

    public string? Email { get; set; }

    public string? Phone { get; set; }

    public string? Address { get; set; }

    public virtual ICollection<Basket> Baskets { get; set; } = new List<Basket>();

    public virtual ICollection<Sale> Sales { get; set; } = new List<Sale>();
}
